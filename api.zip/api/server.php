<?php
define('DOC_ROOT_PATH', $_SERVER['DOCUMENT_ROOT'].'/');
require DOC_ROOT_PATH . './includes/db_config.php';

ini_set('max_execution_time', 150); //300 seconds = 5 minutes
$premium = $mysqli->query("SELECT * FROM server_list ORDER BY server_name ASC");
while($premium_row = $premium->fetch_assoc())
{
	$server_ip = $premium_row['server_ip'];
	$servers = @fsockopen($server_ip, 80, $errno, $errstr, 2);
	
	$state = $servers ? "Online" : "Offline";
	$status[] = array('Server' => $premium_row['server_name'], 'Status' => $state);
}

$data = array('Server Status' => $status);
echo json_encode($data);

?>