<?php
ini_set('max_execution_time', 150);
$DB_host = "mysql1.blazingfast.io";
$DB_user = "vpnngpin_dave01";
$DB_pass = "pinoytayo2021";
$DB_name = "vpnngpin_dave01";
date_default_timezone_set('Asia/Manila');

$mysqli = new MySQLi($DB_host,$DB_user,$DB_pass,$DB_name);
if ($mysqli->connect_error) {
    die('Error: ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}

$values = array();
$username = $_GET['username'];
$username = $mysqli->real_escape_string($username);
$password = $_GET['password'];
$password = $mysqli->real_escape_string($password);
$query = $mysqli->query("SELECT *
FROM 
users
WHERE 
user_name='".$username."'
AND auth_vpn='".md5($password)."'
");

if($query->num_rows > 0)
{
	$row = $query->fetch_assoc();

	if(($row['duration'] OR $row['vip_duration'] OR $row['private_duration']) > 0 && $_GET['type'] == 'premium' && $row['status'] == 'live'){
	http_response_code(200);
	}elseif(($row['vip_duration'] OR $row['private_duration']) > 0 && $_GET['type'] == 'vip' && $row['status'] == 'live'){
	http_response_code(200);
	}elseif($row['private_duration'] > 0 && $_GET['type'] == 'private' & $row['status'] == 'live'){
	http_response_code(200);
	}else{
	http_response_code(407);
	}
}else{
	http_response_code(407);
}

?>