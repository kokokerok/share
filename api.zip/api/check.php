<?php

// Initialize variable for database credentials
$dbhost = 'mysql2.blazingfast.io';
$dbuser = 'mediatek_mtkvpnpanel';
$dbpass = 'panelmtkvpn@@';
$dbname = 'mediatek_mtkvpnpanel';

//Create database connection
  $dblink = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

//Check connection was successful
  if ($dblink->connect_errno) {
     printf("Failed to connect to database");
     exit();
  }

if(!empty($_GET['username'])){  

  $user_id = $_GET['username'];
  $userfinal = $user_id;
  
//Initialize array variable
  $dbdata = array();
  $arr = array('error' => 'username/password');
  
    $query = "SELECT user_name FROM users WHERE user_name = $userfinal";
    $result = mysqli_query($conn, $query);

    $result1 = $dblink->query("SELECT duration AS 'premium', 
								   vip_duration AS 'vip',
								   private_duration AS 'private'
							FROM users WHERE user_name='$userfinal'");
    
    if (  mysqli_num_rows ( $result1 ) === 1 ){

        //Fetch into associative array
        while ( $row = $result1->fetch_assoc())  {
	        $dbdata = $row;
                                    }

            //Print array in JSON format
        echo json_encode($dbdata);      

        }

        else {

           echo json_encode($arr); 
        }

}else{
    
    $arr = array('error' => 'username/password');

    echo json_encode($arr);
}
?>