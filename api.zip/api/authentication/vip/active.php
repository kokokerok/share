<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
require_once '../../../includes/functions.php';

if(isset($_GET['key']) && !empty($_GET['key'])){
    
    $key = $_GET['key'];
    
    if($key = 'Tknetwork') {
        $data = '';
        $query = $db->sql_query("SELECT user_name, user_pass FROM users WHERE (vip_duration > 0 || private_duration > 0) AND is_freeze = 0 ORDER by user_id DESC");
        
        while( $row = $db->sql_fetchrow($query) )
        {
        	$data .= '';
        	$username = $row['user_name'];
        	$user_pass = $db->decrypt_key($row['user_pass']);
        	$user_pass = $db->encryptor('decrypt',$user_pass);
        	$data .= '/usr/sbin/useradd -p $(openssl passwd -1 '.$user_pass.') -s /bin/false -M '.$username.' &> /dev/null;'.PHP_EOL;
        }
        
        echo $data;
    }else{
        echo 'Invalid Key!';
    }
}else{
    echo 'Invalid Key!';
}
?>