<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
require_once '../includes/functions.php';

        $data = "";
        $data .= '{';
        $data .= '"inbounds": [';
        $data .= '{';
        $data .= '"port": 10000,';
        $data .= '"listen":"127.0.0.1",';
        $data .= '"protocol": "vmess",';
        $data .= '"settings": {';
        $data .= '"clients": [';
                
            $query = $db->sql_query("SELECT * FROM users WHERE (is_freeze = 0 AND vip_duration > 0 OR is_freeze = 0 AND private_duration > 0) AND uuid != '' ORDER by user_id DESC");
                
                while( $row = $db->sql_fetchrow($query) )
                {
                    $data .= "{";
                	$uuid = $row['uuid'];				
                	$data .= '"id": "'.$uuid.'",';
                	$data .= '"alterId": 0';
                	$data .= "},";
                }
                
        $data .= "{";
        $data .= '"id": "8a3117db-6f73-480a-9b3e-fdaa12a020eb",';
        $data .= '"alterId": 0';
        $data .= "}";
        $data .= ']';
        $data .= '},';
        $data .= '"streamSettings": {';
        $data .= '"network": "ws",';
        $data .= '"wsSettings": {';
        $data .= '"path": "/unexpected"';
        $data .= '}';
        $data .= '}';
        $data .= '}';
        $data .= '],';
                
        $data .= '"outbounds": [';
        $data .= '{';
        $data .= '"protocol": "freedom",';
        $data .= '"settings": {}';
        $data .= '}';
        $data .= ']';
        $data .= '}';
        
    echo $data;

?>
