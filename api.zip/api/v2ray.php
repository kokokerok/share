<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
ini_set('max_execution_time', 150);

$DB_host = "localhost";
$DB_user = "surfings_vicathnew";
$DB_pass = "vicsonvicathnew";
$DB_name = "surfings_vicathnew";

date_default_timezone_set('Asia/Manila');

$mysqli = new MySQLi($DB_host,$DB_user,$DB_pass,$DB_name);
if ($mysqli->connect_error) {
    die('Error: ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}

 $data = "";
        $data .= '{';
        $data .= '"inbounds": [';
        $data .= '{';
        $data .= '"port": 10000,';
        $data .= '"listen":"127.0.0.1",';
        $data .= '"protocol": "vmess",';
        $data .= '"settings": {';
        $data .= '"clients": [';
                
            $query = $db->sql_query("SELECT * FROM users WHERE (duration > 0 AND is_freeze = 0 OR is_freeze = 0 AND vip_duration > 0 OR is_freeze = 0 AND private_duration > 0) AND uuid != '' ORDER by user_id DESC");
                
                while( $row = $db->sql_fetchrow($query) )
                {
                    $data .= "{";
                	$uuid = $row['uuid'];				
                	$data .= '"id": "'.$uuid.'",';
                	$data .= '"alterId": 0';
                	$data .= "},";
                }
                
        $data .= "{";
        $data .= '"id": "8a3117db-6f73-480a-9b3e-fdaa12a020eb",';
        $data .= '"alterId": 0';
        $data .= "}";
        $data .= ']';
        $data .= '},';
        $data .= '"streamSettings": {';
        $data .= '"network": "ws",';
        $data .= '"wsSettings": {';
        $data .= '"path": "/vicath"';
        $data .= '}';
        $data .= '}';
        $data .= '}';
        $data .= '],';
                
        $data .= '"outbounds": [';
        $data .= '{';
        $data .= '"protocol": "freedom",';
        $data .= '"settings": {}';
        $data .= '}';
        $data .= ']';
        $data .= '}';

$location = '/home/surfings/vicath-vpn.cf/profile/1/premiumaccount.txt';

$fp = fopen($location, 'w');
fwrite($fp, $data) or die("Unable to open file!");
fclose($fp);

#VIPGENERATED

$data2 = "";
$data2 .= '{';
$data2 .= '"inbounds": [';
$data2 .= '{';
$data2 .= '"port": 10000,';
$data2 .= '"listen":"127.0.0.1",';
$data2 .= '"protocol": "vmess",';
$data2 .= '"settings": {';
$data2 .= '"clients": [';

$ACCOUNT2 ="(vip_duration or private_duration) > 0 AND status='live' AND v2ray_id != ''";

$query2 = $mysqli->query("SELECT * FROM users WHERE ".$ACCOUNT2." ");

while($row2 = $query2->fetch_assoc())
{
    $data2 .= "{";
	$password2 = $row2['user_name'];
	$v2ray2 = $row2['v2ray_id'];				
	$data2 .= '"id": "'.$v2ray2.'",';
	$data2 .= '"alterId": 0';
	$data2 .= "},";
}
$data2 .= "{";
$data2 .= '"id": "8a3117db-6f73-480a-9b3e-fdaa12a020eb",';
$data2 .= '"alterId": 0';
$data2 .= "}";
$data2 .= ']';
$data2 .= '},';
$data2 .= '"streamSettings": {';
$data2 .= '"network": "ws",';
$data2 .= '"wsSettings": {';
$data2 .= '"path": "/universal"';
$data2 .= '}';
$data2 .= '}';
$data2 .= '}';
$data2 .= '],';
$data2 .= '"outbounds": [';
$data2 .= '{';
$data2 .= '"protocol": "freedom",';
$data2 .= '"settings": {}';
$data2 .= '}';
$data2 .= ']';
$data2 .= '}';

$location2 = '/home/surfings/vicath-vpn.cf/profile/1/vipaccount.txt';

$fp2 = fopen($location2, 'w');
fwrite($fp2, $data2) or die("Unable to open file!");
fclose($fp2);

#PrivateGENERATED

$data3 = "";
$data3 .= '{';
$data3 .= '"inbounds": [';
$data3 .= '{';
$data3 .= '"port": 10000,';
$data3 .= '"listen":"127.0.0.1",';
$data3 .= '"protocol": "vmess",';
$data3 .= '"settings": {';
$data3 .= '"clients": [';

$ACCOUNT3 ="private_duration > 0 AND status='live' AND v2ray_id != ''";

$query3 = $mysqli->query("SELECT * FROM users WHERE ".$ACCOUNT3." ");

while($row3 = $query3->fetch_assoc())
{
    $data3 .= "{";
	$password3 = $row3['user_name'];
	$v2ray3 = $row3['v2ray_id'];				
	$data3 .= '"id": "'.$v2ray3.'",';
	$data3 .= '"alterId": 0';
	$data3 .= "},";
}
$data3 .= "{";
$data3 .= '"id": "8a3117db-6f73-480a-9b3e-fdaa12a020eb",';
$data3 .= '"alterId": 0';
$data3 .= "}";
$data3 .= ']';
$data3 .= '},';
$data3 .= '"streamSettings": {';
$data3 .= '"network": "ws",';
$data3 .= '"wsSettings": {';
$data3 .= '"path": "/universal"';
$data3 .= '}';
$data3 .= '}';
$data3 .= '}';
$data3 .= '],';
$data3 .= '"outbounds": [';
$data3 .= '{';
$data3 .= '"protocol": "freedom",';
$data3 .= '"settings": {}';
$data3 .= '}';
$data3 .= ']';
$data3 .= '}';

$location3 = '/home/surfings/vicath-vpn.cf/profile/1/privateaccount.txt';

$fp3 = fopen($location3, 'w');
fwrite($fp3, $data3) or die("Unable to open file!");
fclose($fp3);

$mysqli->close();
?>